# EEG Demo

_Version 0.3.1_
## What's new in this release?
*Release date: 2020-xx-xx*
- Updated to Python 3 and PyQt5
- Has been tested on Windows and OSX
- Updated editable cfg file that allows for user configuration 
of a variety of parameters

### Requirements
- Python 3.7.x
- PyQt5: 
https://www.riverbankcomputing.com/software/pyqt/download5
- Numpy/SciPy: http://www.numpy.org/
- PyQtGraph: http://www.pyqtgraph.org/
- ReportLab: http://www.reportlab.com/software/

Please note that the recommended way to deal with dependencies is to install 
anaconda:
https://www.continuum.io/downloads

This should take care of all dependencies except for pyqt5, which
can be installed like so:

    conda install -c anaconda pyqt=5.13.1
    conda install pyqtgraph
    conda install reportlab

### How to Run Demo:
- Run main.py under $auto-eeg/demo/src with Python

    `python demo/src/main.py`

    `python demo/src/main.py example_edf.edf`

### Directories
- src: This directory includes all Python codes for running
GUI, reading edf files, and reading EEG events from
annotation files.
