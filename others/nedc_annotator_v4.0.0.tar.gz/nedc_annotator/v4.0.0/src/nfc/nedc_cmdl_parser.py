#!/usr/bin/env python

# file: $nedc_nfc/class/python/nedc_cmdl_parser/nedc_cmdl_parser.py
#
# revision history:
#  20160412 (MT): changed the print_usage method to instead print usage
#                 messages based on files
#  20151217 (MG): initial version
#
# usage:
#  import nedc_cmdl_parser as ncp
#  parser = ncp.CommandLineParser(usage_file_a, help_file_a)
#
#------------------------------------------------------------------------------

# import required system modules
#
import argparse
import sys
import os

#------------------------------------------------------------------------------
#
# global variables are listed here
#
#------------------------------------------------------------------------------

#------------------------------------------------------------------------------
#
# classes are listed here
#
#------------------------------------------------------------------------------

# class: CommandLineParser
#
# This class inherits the argparse ArgumentParser object.
# This class is used to edit the format_help method found in the argparse
# module. It defines the help method for this specific tool.
#
class CommandLineParser(argparse.ArgumentParser):

    # method: Constructor
    #
    # arguments:
    #  -usage_file: a short explanation of the command that is printed when 
    #              it is run without argument.
    #  -help_file: a full explanation of the command that is printed when 
    #              it is run with -help argument.
    #
    #
    # return values: none
    #
    def __init__(self, usage_file_a, help_file_a):

        argparse.ArgumentParser.__init__(self)
        self.set_usage(usage_file_a)
        self.set_help(help_file_a)


    # method: set_usage
    #
    # arguments:
    #  usage_file: a file containing a one line usage message
    #
    # return: none
    #
    # This method is used to set the usage message.
    #
    def set_usage(self, usage_file_a):
        
        # set the usage message to a class variable to be used by other methods
        #
        self.usage_file = usage_file_a

        # if the file does not exist, return an error
        #
        if os.path.isfile(usage_file_a) == False:

            print ("%s: error opening the usage file (%s)" \
                % (sys.argv[0], usage_file_a))


    # method: print_usage
    #
    # arguments: none
    #
    # return: none
    #
    # This method is used to print the usage message from a file.
    #
    def print_usage(self):
        
        # check if the usage message exists
        #
        if os.path.isfile(self.usage_file) is True:
            
            # returns the usage message line if the file exists
            #
            with open(self.usage_file, 'r') as f:
                usage_file = f.read()
            print (usage_file)


    # method: set_help
    #
    # arguments:
    #  help_file: the full pathname of the help file
    #
    # return: none
    #
    # This method is used to set the help message.
    #
    def set_help(self, help_file_a):
        
	# set the help message to a class variable to be used by other methods
        #
        self.help_file = help_file_a

        # if the file does not exist, return an error
        #
        if os.path.isfile(help_file_a) == False:

            print ("%s: error opening the help file (%s)" \
                % (sys.argv[0], help_file_a))


    # method: format_help
    #
    # arguments: none
    #
    # return:
    #  help_file: string containing text from help file
    #
    # This class is used to define the specific help message to be used.
    #
    def format_help(self):

        # check if help file exists
        #
        if os.path.isfile(self.help_file) is True:

            # returns lines in help file if it exists
            #
            with open(self.help_file, 'r') as f:
                help_file = f.read()
            return(help_file)

        # if the help file cannot be found, prints an error statement and exits
        #
        else:
            print ("%s: error opening the help file (%s)" \
                % (sys.argv[0], help_file_a))


        #
        # end of function

#
# end of file
