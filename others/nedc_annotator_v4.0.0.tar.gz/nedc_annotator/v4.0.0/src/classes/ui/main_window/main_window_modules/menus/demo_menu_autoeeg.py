# -*- coding: utf-8 -*-

from PyQt5 import QtGui

class DemoMenuAutoEEG(QtGui.QMenu):
    def __init__(self,
                 menu_bar_parent_a):
        QtGui.QMenu.__init__(self,
                             menu_bar_parent_a)

        self.actions_setup()
        self.actions_connect_and_name()


    def actions_setup(self):
        self.action_about_autoeeg = QtGui.QAction(self)
        self.action_about_autoeeg.setEnabled(True)

        self.action_preferences = QtGui.QAction(self)
        self.action_preferences.setEnabled(True)

        self.action_quit_autoeeg = QtGui.QAction(self)
        self.action_quit_autoeeg.setEnabled(True)

    def actions_connect_and_name(self):
        self.addAction(self.action_about_autoeeg)
        # self.addSeparator()
        self.addAction(self.action_preferences)
        self.addAction(self.action_quit_autoeeg)

        self.setTitle("AutoEEG")
        self.action_about_autoeeg.setText("About AutoEEG")
        self.action_preferences.setText("Preferences...")
        self.action_quit_autoeeg.setText("Quit AutoEEG")
