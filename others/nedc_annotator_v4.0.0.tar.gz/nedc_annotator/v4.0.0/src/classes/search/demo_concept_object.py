
class DemoConceptObject:

    def __init__(start_positions_a,
                 end_positions_a,
                 attr_types_a):

        self.start_positions_a = start_positions_a
        self.end_positions_a = end_positions_a
        self.attr_types = attr_types_a
        
