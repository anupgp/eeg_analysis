#!/usr/bin/env python

# file: $NEDC_NFC/util/python/nedc_edf_reader/nedc_edf_reader.py
#
# revision history:
#  20160511 (MT): refactored code to comply with ISIP standards and to allow
#                 input from the command line
#  20141212 (MG): modified to support edf files with non-eeg channels
#  20141020 (MG): changed load_edf to read an edf file between two specified
#                 times (t1,t2)
#  20140812 (MG): initial version
#
# usage: nedc_edf_reader [-help] [-st_time val] [-en_time val]
#        [-excluded_channels val] edf_file.edf
#
# This script accepts an edf file as an input, reads the data from the file
# based on the parameters passed to the script, and prints the raw data read.
#------------------------------------------------------------------------------

# import NEDC module
#

#import nedc_cmdl_parser as ncp

# import required system modules
#

from collections import namedtuple
from functools import reduce
import re
import datetime
import operator
import logging
import numpy as np
import sys
import os

#------------------------------------------------------------------------------
#
# global variables are listed here
#
#------------------------------------------------------------------------------

# define the paths for the help and usage files
#
NEDC_HELP_FILE = "/util/python/nedc_edf_reader/nedc_edf_reader.help"
NEDC_USAGE_FILE = "/util/python/nedc_edf_reader/nedc_edf_reader.usage"

# global veriable to support edf files with annotations
#
EVENT_CHANNEL = 'EDF Annotations'
log = logging.getLogger(__name__)

# define the default values for reading edf files
#
NEDC_DEF_ST_TIME = 0.0
NEDC_DEF_EN_TIME = 100.0
NEDC_DEF_EXCLUDED_CHANNELS = \
    'EEG FZ-REF', 'EEG PZ-REF', 'EEG ROC-REF', 'EEG LOC-REF', 'EMG-REF',  \
    'EEG 26-REF', 'EEG 27-REF', 'EEG 28-REF', 'EEG 29-REF', 'EEG 30-REF', \
    'EEG T1-REF', 'EEG T2-REF', 'PHOTIC-REF', 'IBI', 'BURSTS', 'SUPPR', 'PULSE RATE','Fp1','Fp2','F3','F4','C3','C4', 'P3','P4','O1','O2','F7','F8','T3','T4','T5','T6','Fz','E','PG1','PG2','A1','A2','T1','T2','X1','X2','X3','X4','X5','X6','X7','SpO2','EtCO2','DC03','DC04','DC05','DC06','Pulse','C02Wave','Events/Markers','IBI','Bursts','Suppr','Pulse Rate','ECG EKG-REF','RESP ABDOMEN-REF'

#TODO: verify deleted channels
#deleted: 'EEG T1-REF' 'EEG T2-REF' 'EEG FZ-REF' 'EEG PZ-REF'

#------------------------------------------------------------------------------
#
# classes are listed here
#
#------------------------------------------------------------------------------

# class: EDFEndOfData
#
# This class rises when the reading of raw_data reaches the end of the
# specified period
#
class EDFEndOfData:
    pass


# class: BaseEDFReader
#
# This is the main class of edf_reader. It reads an edf file based on the 
# arguments passed to it.
#
class BaseEDFReader:

    # method: constructor
    #
    # arguments:
    #  -edf_file: the edf file to be read
    #  -st_time: the inital time (t1) in the edf file to start reading
    #  -en_time: te time (t2) in the edf file to stop reading
    #  -noneeg_channels_a: the channels in the file which are non-eeg channels
    #
    # return: none 
    #
    def __init__(self, edf_file, st_time, en_time, noneeg_channels_a):
        
        # set class variables for each argument received
        #
        self.file = edf_file
        self.st_time = st_time
        self.en_time = en_time
        self.noneeg_channels = noneeg_channels_a

        # set the default values for the raw data start positions to be 0
        #
        self.t_counter = 0
        self.t_offset = 0
    
    #
    # end of function

    # method: read_header
    #
    # arguments: none
    #
    # return: none
    # 
    # This method reads the header of an edf file using the read_header 
    # function.
    #
    def read_header(self):
      
        self.header = h = edf_header(self.file)
        # calculate the ranges for rescaling
        #
        self.dig_min = h['digital_min']
        self.phys_min = h['physical_min']
        phys_range = h['physical_max'] - h['physical_min']
        dig_range = h['digital_max'] - h['digital_min']

        assert np.all(phys_range > 0)
        assert np.all(dig_range > 0)

        self.gain = phys_range / dig_range

    #
    # end of function

    # method: read_raw_record
    #
    # arguments: none
    #
    # return:
    #  result: a list containing arrays with raw data bytes
    #
    # This method reads a record with data and returns a list containing arrays
    # with raw data bytes.
    #
    def read_raw_record(self):
        result = []

        # This part reads raw data records from start time to end
        # time.
        #

        # set the number of samples per record
        #
        self.n_samples_per_record = self.header['n_samples_per_record']

        # this is used to set the start time for the raw data reading
        #
        self.t_offset = self.header['header_nbytes']

        for nsamp in self.header['n_samples_per_record']:
            self.t_offset += (((nsamp * 2)) * (self.st_time + self.t_counter))

        # jump to the start of the raw data and begin reading
        #
        samples = self.file.seek(self.t_offset, 0)

        # create a pointer for the numer of recordings that should be read
        #
        self.t_counter += 1

        # reads all raw data over the specified period of time for all of the
        # signals
        #
        for nsamp in self.header['n_samples_per_record']:
            samples = self.file.read(nsamp * 2)
            if self.t_counter == (self.en_time - self.st_time + 1):
                raise EDFEndOfData
            result.append(samples)
        return result

    #
    # end of function

    # method: convert_record
    #
    # arguments:
    #  -raw_record: raw data read from the edf file
    #
    # return: a tuple based on information from the header
    #
    # This method converts a raw record into a tuple based on information from
    # the header.
    #
    def convert_record(self, raw_record):

        # initialize variables to be used
        #
        h = self.header
        dig_min, phys_min, gain = self.dig_min, self.phys_min, self.gain
        time = float('nan')
        signals = []
        events = []

        # check the header to see what kind of tuple should be returned
        #
        for (i, samples) in enumerate(raw_record):
            if h['label'][i] == EVENT_CHANNEL:
                ann = tal(samples)
                time = ann[0][0]
                events.extend(ann[1:])
            else:

                # 2-byte little-endian integers
                #
                dig = np.fromstring(samples, '<i2').astype(np.float32)
                phys = (dig - dig_min[i]) * gain[i] + phys_min[i]
                if h['label'][i] not in self.noneeg_channels:
                    signals.append(phys)
                    pass
        return time, signals, events

    #
    # end of function

    # method: read_record
    #
    # arguments: none
    #
    # return: none
    # 
    # This method reads the raw data record using the convert_record method.
    # 
    def read_record(self):
        return self.convert_record(self.read_raw_record())

    #
    # end of function

    # method: records
    #
    # arguments: none                                                          
    #                                                                          
    # return: none                                                             
    #                                                                          
    # This method generates the record.   
    #                                  
    def records(self):
        try:
            while True:
                yield self.read_record()
        except:
            pass

    #
    # end of function

#------------------------------------------------------------------------------
#
# methods are listed here
#
#------------------------------------------------------------------------------

# method: tal
# 
# arguments:
#  tal_str: an EDF+ TAL stream
#
# return: a list with tuples (i.e. onset, duration, annotation) for the stream
#
# This method returns a list of tuples based on a given EDF+ TAL stream.
#
def tal(tal_str):

    exp = '(?P<onset>[+\-]\d+(?:\.\d*)?)' + \
        '(?:\x15(?P<duration>\d+(?:\.\d*)))?' + \
        '(\x14(?P<annotation>[^\x00]*))?' + \
        '(?:\x14\x00)'

    def annotation_to_list(annotation):
        return unicode(annotation, 'utf-8').split('\x14') if annotation else []

    def parse(dic):
        return (
            float(dic['onset']),
            float(dic['duration']) if dic['duration'] else 0.,
            annotation_to_list(dic['annotation']))

    return [parse(m.groupdict()) for m in re.finditer(exp, tal_str)]

#
# end of function

# method: edf_header
# 
# arguments:
#  f: an edf file
#
# return: the header of the given edf file
#
# This method reads the edf file and returns the necessary header information
#
def edf_header(f):

    h = {}

    # check file position
    #
    assert f.tell() == 0

    # check if this file is an edf file.
    #
    assert f.read(8) == b'0       '

    # recording info.
    #
    h['local_subject_id'] = f.read(80).decode().strip()
    h['local_recording_id'] = f.read(80).decode().strip()
   
    # parse time-stamp.
    #
    (day, month, year) = [(x) for x in re.findall('(\d+)', f.read(8).decode())]
    dmy_strformat = str(year) + "/" + str(month) + "/" + str(day)
    dmy_dateformat = datetime.datetime.strptime(dmy_strformat, "%y/%m/%d")
    h["startdate_of_recording"] = datetime.datetime.strftime(
        dmy_dateformat, "%B %d, %Y")

    (hour, minute, sec) = [(x) for x in re.findall('(\d+)', f.read(8).decode())]
    hms_strformat = str(hour) + ":" + str(minute) + ":" + str(sec)
    hms_dateformat = datetime.datetime.strptime(hms_strformat, "%H:%M:%S")
    h["starttime_of_recording"] = datetime.datetime.strftime(
        hms_dateformat, "%H:%M:%S")

    # misc.
    #
    h['header_nbytes'] = int(f.read(8).decode())
    subtype = f.read(44).decode()[:5]
    h['EDF+'] = subtype in ['EDF+C', 'EDF+D']
    h['contiguous'] = subtype != 'EDF+D'
    h['n_records'] = int(f.read(8))

    # record_length in seconds
    #
    h['record_length'] = float(f.read(8))
    nchannels = h['n_channels'] = int(f.read(4))

    # read channel info.
    #
    channels = range(h['n_channels'])
    h['label'] = [f.read(16).decode().strip() for n in channels]
    h['transducer_type'] = \
        [f.read(80).strip() for n in channels]
    h['units'] = [f.read(8).strip() for n in channels]
    h['physical_min'] = \
        np.asarray([float(f.read(8)) for n in channels])
    h['physical_max'] = \
        np.asarray([float(f.read(8)) for n in channels])
    h['digital_min'] = \
        np.asarray([float(f.read(8)) for n in channels])
    h['digital_max'] = \
        np.asarray([float(f.read(8)) for n in channels])
    h['prefiltering'] = \
        [f.read(80).strip() for n in channels]
    h['n_samples_per_record'] = \
        [int(f.read(8)) for n in channels]
    f.read(32 * nchannels)

    assert f.tell() == h['header_nbytes']
    return h

#
# end of fucntion
                                                      
# method: load_edf                                                      
#                                                                          
# arguments:                                                               
#  edf_file: the edf file to be read                                      
#  st_time: the inital time (t1) in the edf file to start reading         
#  en_time: te time (t2) in the edf file to stop reading                  
#  noneeg_channels_a: the channels in the file which are non-eeg channels 
#                                                                          
# return:                                                             
#  tup: a named tuple with information read from the read EDF file
#
# This method is a basic reader for EDF and EDF+ files. Unlike BaseEDFReader, 
# this reader expects a single, fixed sample rate for all channels, and it
# reads the file between st_time and en_time.
#
def load_edf(edffile, st_time, en_time):

    if isinstance(edffile, str):

        # convert filename to file
        #
        with open(edffile, 'rb') as f:
            return load_edf(f, st_time, en_time)

    # create a reader object
    #
    reader = BaseEDFReader(edffile,
                           st_time,
                           en_time,
                           NEDC_DEF_EXCLUDED_CHANNELS)
    reader.read_header()

    # initialize the header from the read edf file
    #
    h = reader.header
    log.debug('EDF header: %s' % h)

    # get sample rate info
    #
    nsamp = np.unique(
        [n for (l, n) in zip(h['label'],
         h['n_samples_per_record'])
            if (l != EVENT_CHANNEL and l not in NEDC_DEF_EXCLUDED_CHANNELS)])

    assert nsamp.size == 1, 'Multiple sample rates not supported!'
    sample_rate = float(nsamp[0]) / h['record_length']
  
    rectime, X, annotations = zip(*reader.records())
    X = np.hstack(X)
    annotations = reduce(operator.add, annotations)

    chan_lab = [lab for lab in reader.header['label']
                if (lab != EVENT_CHANNEL and lab not in NEDC_DEF_EXCLUDED_CHANNELS)]

    # create time-stamps
    #
    if reader.header['contiguous']:
        time = np.arange(X.shape[1]) / sample_rate

        # this line adds to change the start point.
        #
        time = time + st_time

    else:
        reclen = reader.header['record_length']
        within_rec_time = np.linspace(0, reclen, nsamp, endpoint=False)

        # change the start time based on the parameters
        # 
        time = np.hstack([t + within_rec_time + st_time for t in rectime])

    # compute total time of the recording
    #
    totaltime = h['n_records'] * h['record_length']

    # return whole duration of the EDF
    #
    local_patient_identification = h['local_subject_id']

    # create the namedtuple
    #
    tup = namedtuple('EDF', 'X sample_rate chan_lab time totaltime \
        local_patient_identification \
        startdate_of_recording starttime_of_recording')

    # return the namedtuple
    #
    return tup(X, sample_rate, chan_lab, time, totaltime,
               local_patient_identification, h["startdate_of_recording"],
               h["starttime_of_recording"])

#
# end of function

# method: return_header
# 
# arguments: edffile
#
# return: the header of an edf file
#
# This method accepts an edf file as an input and returns the header
#
def return_header(edffile):

    if isinstance(edffile, str):
        with open(edffile, 'rb') as f:
            return return_header(f)


    reader = BaseEDFReader(edffile, 0, 0, [])
    reader.read_header()
    h = reader.header
    return h

#
# end of function

#------------------------------------------------------------------------------
#
# the main program starts here
#
#------------------------------------------------------------------------------

# method: main
#
# arguments: none
#
# return: none
#
# This method calls the load_edf method to read an edf file (given as a command
# line argument). The results are printed to a results text file, which is
# specified as an input to the script.
#
def main():

    # construct the full path of the help and usage files
    #
    help_file = os.environ.get("NEDC_NFC") + NEDC_HELP_FILE
    usage_file = os.environ.get("NEDC_NFC") + NEDC_USAGE_FILE

    # initialize the variables to their default values
    #
    st_time_a = NEDC_DEF_ST_TIME
    en_time_a = NEDC_DEF_EN_TIME
    excluded_channels_a = NEDC_DEF_EXCLUDED_CHANNELS

    # create a command line parser
    #
    parser = ncp.CommandLineParser(usage_file, help_file);

    # define the command line arguments
    #
    parser.add_argument("file", type = str)
    parser.add_argument("-st_time", type = float)
    parser.add_argument("-en_time", "-e", type = float)
    parser.add_argument("-excluded_channels", "-x", type =str, nargs='*')
    parser.add_argument("-help", action="help")

    # print the usage message if no arguments are received
    #
    if len(sys.argv)==1:
        parser.print_usage()
        exit(-1)

    # check received arguments to see if an edf file was specified
    #
    edf_passed = False
    help_file = False
    for params in sys.argv:
        if os.path.isfile(params) and not params.endswith(".py"):
            edf_passed = True
        if params.startswith("-h"):
            help_file = True

    # if no edf file was passed as an argument, give an error
    #
    if edf_passed is False and help_file is False:
        print ("%s: no edf file given as an argument" % (sys.argv[0]))
        exit(-1)

    # parse the command line
    #
    args = parser.parse_args()

    # set and check the values received from arguments to variables
    #
    if args.st_time is not None:
        st_time_a = args.st_time

    if args.en_time is not None:
        en_time_a = args.en_time

    if args.excluded_channels is not None:
        excluded_channels_a = args.excluded_channels

    if args.file is not None:
        edf_file_a = args.file

    # give an error if the start time is greater than the end time
    #
    if (st_time_a >= en_time_a):
        print ("%s: start time should be less than the end time" % (sys.argv[0]))
        exit(-1)

    # read edf file and store results in a tuple
    # 
    results = load_edf(edf_file_a, st_time_a, en_time_a, excluded_channels_a)

    # print the raw data read from the file
    #
    print (results)

#
# end of main

# begin gracefully
#
if __name__ == "__main__":
    main()

#
# end of file
